#include "common.h"
#include "SHMreqchannel.h"
using namespace std;

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/

SHMRequestChannel::SHMRequestChannel(const string _name, const Side _side, int _len) : RequestChannel (_name, _side){
	s1 = "/SHM_" + my_name + "1";
	s2 = "/SHM_" + my_name + "2";
	len = _len;

    shmq1 = new SHMQ (s1, len);
    shmq2 = new SHMQ (s2, len);
    if ()
	
}

SHMRequestChannel::~SHMRequestChannel(){
    SHM_close (wfd);
    SHM_close (rfd);

    SHM_unlink (s1.c_str());
    SHM_unlink (s2.c_str());
}

int SHMRequestChannel::open_ipc (string _pipe_name, int mode){
	int fd = (int) SHM_open(_pipe_name.c_str(), O_RDWR | O_CREAT, 0600, 0);
	if (fd < 0){
		EXITONERROR(_pipe_name);
	}
	return fd;
}

int SHMRequestChannel::cread(void* msgbuf, int bufcapacity){
	return SHM_receive (rfd, (char *) msgbuf, 8192, NULL);
}
int SHMRequestChannel::cwrite(void* msgbuf, int len){
	return SHM_send(wfd, (char *)msgbuf, len, 0);
}

