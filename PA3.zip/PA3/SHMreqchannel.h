
#ifndef _SHMreqchannel_H_
#define _SHMreqchannel_H_

#include "common.h"
#include <semaphore.h>
#include "Reqchannel.h"
#include <string>
#include <sys/mman.h>
using namespace std;
class SHMQ{
private:
    char* segment;
    sem_t* sd;
    sem_t* rd;
    string name;
    int len;
public:
    SHMQ (string _name, int _len): name (_name), len (_len){
        int fd = shm_open(name.c_str(), O_RDWR|O_CREAT, 0600);
        if (fd < 0){
            EXITONERROR ("could not create/open shared memory segment");
        }
        ftruncate(fd, len);

        segment = (char *) mmap(NULL, len, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
        if (!segment){
            EXITONERROR ("Cannot map");
        }
        rd = sem_open ((name + "_rd").c_str(), O_CREAT, 0600, 1);
        sd = sem_open ((name + "_sd").c_str(), O_CREAT, 0600, 0);
    }
    int my_send (void* msg, int len){
        sem_wait (rd);
        memcpy (segment, msg, len);
        sem_post (sd);
    }
    int my_shm_recv (void* msg, int len){
        sem_wait (sd);
        memcpy (msg, segment, len);
        sem_post (rd);
    }
    ~SHMQ (){
        sem_close (sd);
        sem_close (rd);
        sem_unlink ((name + "_rd").c_str());
        sem_unlink ((name + "_sd").c_str());

        munmap (segment, len);
        shm_unlink (name.c_str ());

    }
};



class SHMRequestChannel: public RequestChannel{
	
private:
    SHMQ* shmq1;
    SHMQ* shmq2;
    int len;
public:
	SHMRequestChannel(const string _name, const Side _side, int _len);


	~SHMRequestChannel();
	/* Destructor of the local copy of the bus. By default, the Server Side deletes any IPC 
	 mechanisms associated with the channel. */


	int cread (void* msgbuf, int bufcapacity);
	/* Blocking read of data from the channel. You must provide the address to properly allocated
	memory buffer and its capacity as arguments. The 2nd argument is needed because the recepient 
	side may not have as much capacity as the sender wants to send.
	
	In reply, the function puts the read data in the buffer and  
	returns an integer that tells how much data is read. If the read fails, it returns -1. */
	
	int cwrite(void *msgbuf , int msglen);
	/* Writes msglen bytes from the msgbuf to the channel. The function returns the actual number of 
	bytes written and that can be less than msglen (even 0) probably due to buffer limitation (e.g., the recepient
	cannot accept msglen bytes due to its own buffer capacity. */
	 


};

#endif
