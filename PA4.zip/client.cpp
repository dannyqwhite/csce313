#include "common.h"
#include "BoundedBuffer.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "FIFOreqchannel.h"
#include <time.h>
#include <thread>
using namespace std;


FIFORequestChannel* create_new_channel (FIFORequestChannel* mainchan){
    char name [1024];
    MESSAGE_TYPE m=NEWCHANNEL_MSG;
    mainchan->cwrite(&m,sizeof(m));
    mainchan->cread (name,1024);
    FIFORequestChannel* newchan=new FIFORequestChannel (name, FIFORequestChannel::CLIENT_SIDE);
    return newchan;

}

void patient_thread_function(int n, int pno, BoundedBuffer* request_buffer){

    datamsg d (pno, 0.0, 1);
    double resp=0;
    for (int i=0;i<n;i++){
        request_buffer->push ((char*)&d, sizeof(datamsg));
        d.seconds+=0.004;
    }
}



void worker_thread_function(FIFORequestChannel* chan, BoundedBuffer* response_buffer, HistogramCollection* hc, int mb){
    char buf[1024];
    double rp=0;
    char rb[mb];
	
	
    while(true)
	{
        response_buffer->pop(buf,1024);
        MESSAGE_TYPE* m = (MESSAGE_TYPE *) buf;
        if(*m==DATA_MSG)
        {
            chan->cwrite(buf,sizeof(datamsg));
            chan->cread(&rp, sizeof(double));
            hc->update(((datamsg*)buf)->person,rp);
        }
        else if(*m==QUIT_MSG)
        {
            chan->cwrite(m,sizeof(MESSAGE_TYPE));
            delete chan;
            break;
        }
        else if(*m==FILE_MSG)
        {
            filemsg* fm=(filemsg*) buf;
            string file_names=(char*)(fm+1);
            int size_=sizeof(filemsg)+file_names.size()+1;
            chan->cwrite(buf,size_);
            chan->cread(rb,mb);
			
            string recvfname="recv/"+file_names;
            FILE* fp=fopen(recvfname.c_str(), "r+");
            fseek (fp, fm->offset, SEEK_SET);
            fwrite(rb, 1, fm->length, fp);
            fclose(fp);
        }
    }
}

void file_threads(string filename, BoundedBuffer* request_buffer, FIFORequestChannel* chan, int mb){
    string f_name = filename;
    char buf [2048];
    filemsg p (1,2);

    memcpy (buf, &p, sizeof(p));
    strcpy (buf+sizeof(p),filename.c_str());
    chan->cwrite(buf, sizeof(p)+filename.size()+1);
	
    __int64_t filelength;
    chan->cread(&filelength, sizeof(filelength));
    FILE* fp = fopen(f_name.c_str(), "f");
    fseek(fp, filelength, SEEK_SET);
	
    fclose(fp);
    filemsg* fm = (filemsg *) buf;
	
    __int64_t remlen=filelength;
    while(remlen > 0)
    {
        fm->length = min(remlen, (__int64_t) mb);
        request_buffer->push(buf,sizeof(filemsg) + filename.size() + 1);
        fm->offset+=fm->length;
        remlen-=fm->length;
    }
}
/*
void histogram_thread_function (/*add necessary arguments*/){
    /*
		Functionality of the histogram threads

     ****COULDN'T GET IT TO WORK****
     **EXPERIMENTING WITH FILE THREADS TO POSSIBLY HELP RUNTIME****
    */
}
*/


int main(int argc, char *argv[])
{
    int n = 100;    //default number of requests per "patient"
    int p = 10;     // number of patients [1,15]
    int w = 100;    //default number of worker threads
    int b = 20; 	// default capacity of the request buffer, you should change this default
	int m = MAX_MESSAGE; 	// default capacity of the message buffer

    srand(time_t(NULL));
    bool danger = 0;
    string f_name ="";

    int opt = -1;
    while((opt=getopt(argc, argv, "w:f:b:h:m:n:p:"))!=-1){
        switch(opt){
            case 'm':
                m=atoi(optarg);
                break;
            case 'n':
                n=atoi(optarg);
                break;
            case 'p':
                p=atoi(optarg);
                break;
            case 'w':
                w=atoi(optarg);
                break;
            case 'f':
                danger=1;
                f_name=optarg;
                break;
            case 'b':
                b=atoi(optarg);
                break;


        }
    }

    
    
    int pid = fork();
    if (pid == 0)
    {
        execl ("server", "server", (char *)NULL);
    }
    
	FIFORequestChannel* chan = new FIFORequestChannel("control", FIFORequestChannel::CLIENT_SIDE);
    BoundedBuffer request_buffer(b);
	HistogramCollection hc;

	for (int i=0;i<p;i++)
	{
	    Histogram* h = new Histogram (10, -2.0, 2.0);
	    hc.add(h);
	}

	FIFORequestChannel* wchans [w];
	for (int i=0;i<w;i++)
	{
	    wchans [i] = create_new_channel(chan);
	}
    struct timeval start, end;
    gettimeofday (&start, 0);
    if(danger==0)
    {
        thread patient [p];
        for (int i=0;i<p;i++)
        {
            patient [i] = thread(patient_thread_function, n, i+1, &request_buffer);
        }
        thread work[w];
        for (int i = 0; i < w; i++)
        {
            work[i] = thread(worker_thread_function, wchans[i], &request_buffer, &hc, m);
        }
        for (int i=0;i<p;i++)
        {
            patient [i].join();
        }
        for (int i = 0; i < w; i++)
        {
            MESSAGE_TYPE q = QUIT_MSG;
            request_buffer.push((char *) &q, sizeof(q));
        }
        for (int i = 0; i < w; i++)
        {
            work[i].join();
        }

    }
    else
        {
        thread file_thread(file_threads, f_name, &request_buffer, chan, m);
        thread work[w];
        for (int i = 0; i < w; i++)
        {

            work[i] = thread(worker_thread_function, wchans[i], &request_buffer, &hc, m);
        }
        file_thread.join();
        for (int i = 0; i < w; i++)
        {
            MESSAGE_TYPE q = QUIT_MSG;
            request_buffer.push((char *) &q, sizeof(q));
        }
        for (int i = 0; i < w; i++)
        {
            work[i].join();
        }

    }
    gettimeofday (&end, 0);
	hc.print ();
    int secs = (end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec)/(int) 1e6;
    int usecs = (int)(end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec)%((int) 1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;
    MESSAGE_TYPE q = QUIT_MSG;
    chan->cwrite ((char *) &q, sizeof (MESSAGE_TYPE));
    cout << "All Done!!!" << endl;
    delete chan;
}
