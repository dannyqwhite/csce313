#ifndef BoundedBuffer_h
#define BoundedBuffer_h

#include <stdio.h>
#include <queue>
#include <string>
#include <thread>
#include <mutex>
#include <assert.h>
#include <vector>
#include <condition_variable>
using namespace std;

class BoundedBuffer
{
private:
	int capacity;
	queue<vector<char>> list;
	mutex m;
	condition_variable data_available;
	condition_variable slot_available;

public:
	BoundedBuffer(int cap)
	{
        capacity = cap;
	}
	~BoundedBuffer()
	{

	}

	void push(char* data, int length)
	{
        vector<char> dat (data,data+length);
		unique_lock<mutex> l(m);
		slot_available.wait(l, [this]{return list.size()<capacity;});
		list.push(dat);
		l.unlock();
		data_available.notify_one();
	}

	int pop(char* buf, int buf_capacity)
	{
		unique_lock<mutex> l (m);
		data_available.wait(l, [this]{return list.size()>0;});
		vector<char> d=list.front();
		list.pop();
		l.unlock();
		assert(d.size()<=buf_capacity);
		memcpy(buf,d.data(),d.size());
		slot_available.notify_one();
        return d.size();
	}
};

#endif
