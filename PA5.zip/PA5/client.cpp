#include "common.h"
#include "BoundedBuffer.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "FIFOreqchannel.h"
#include <thread>
#include <sys/wait.h>
#include <sys/epoll.h>

using namespace std;

FIFORequestChannel *create_new_channel(FIFORequestChannel *mainchan)
{
    char name[1024];
    MESSAGE_TYPE m = NEWCHANNEL_MSG;
    mainchan->cwrite(&m, sizeof(m));
    mainchan->cread(name, 1024);
    FIFORequestChannel *newchan = new FIFORequestChannel(name, FIFORequestChannel::CLIENT_SIDE);
    return newchan;
}

void patient_thread_function(int n, int pno, BoundedBuffer *request_buffer)
{
    datamsg d(pno, 0.0, 1);
    for (int i = 0; i < n; i++)
    {
        request_buffer->push((char *)&d, sizeof(datamsg));
        d.seconds += 0.004;
    }
}

void file_thread_function(string fname, BoundedBuffer *request_buffer, FIFORequestChannel *chan, int mb)
{
    string recvfname = "recv/" + fname;
    char buf[1024];
    filemsg f(0, 0);
    memcpy(buf, &f, sizeof(f));
    strcpy(buf + sizeof(f), fname.c_str());
    chan->cwrite(buf, sizeof(f) + fname.size() + 1);
    __int64_t filelength;
    chan->cread(&filelength, sizeof(filelength));
    FILE *fp = fopen(recvfname.c_str(), "w");
    fseek(fp, filelength, SEEK_SET);
    fclose(fp);
    filemsg *fm = (filemsg *)buf;
    __int64_t remlen = filelength;
    while (remlen > 0)
    {
        fm->length = min(remlen, (__int64_t)mb);
        request_buffer->push(buf, sizeof(filemsg) + fname.size() + 1);
        fm->offset += fm->length;
        remlen -= fm->length;
    }
}

void worker_thread_function(FIFORequestChannel *chan, BoundedBuffer *request_buffer, HistogramCollection *hc, int mb)
{
    char buf[1024];
    double resp = 0;
    char recvbuf[mb];
    while (true)
    {
        request_buffer->pop(buf, 1024);
        MESSAGE_TYPE *m = (MESSAGE_TYPE *)buf;

        if (*m == DATA_MSG)
        {
            chan->cwrite(buf, sizeof(datamsg));
            chan->cread(&resp, sizeof(double));
            hc->update(((datamsg *)buf)->person, resp);
        }
        else if (*m == QUIT_MSG)
        {
            chan->cwrite(m, sizeof(MESSAGE_TYPE));
            delete chan;
            break;
        }
        else if (*m == FILE_MSG)
        {
            filemsg *fm = (filemsg *)buf;
            string fname = (char *)(fm + 1);
            int sz = sizeof(filemsg) + fname.size() + 1;
            chan->cwrite(buf, sz);
            chan->cread(recvbuf, mb);
            string recvfname = "recv/" + fname;
            FILE *fp = fopen(recvfname.c_str(), "r+");
            fseek(fp, fm->offset, SEEK_SET);
            fwrite(recvbuf, 1, fm->length, fp);
            fclose(fp);
        }
    }
}

void event_polls(int n, int p, int w, int mb, FIFORequestChannel** wchan, BoundedBuffer* request_buffer, HistogramCollection* hc)
{ 
    char buf[1024];
    double resp = 0;
    char recvbuf[mb];

    // create epoll list that is empty
    struct epoll_event first;
    struct epoll_event events[w];
    int epoll_file = epoll_create1(0);
    if (epoll_file == -1)
    {
        EXITONERROR("epoll_create1");
    }

    // mapping for future access
    unordered_map<int, int> index_fd;
    vector<vector<char>> state(w);

    int num_sent = 0;
    int num_recv = 0;
    bool quit_recv = false;

    // priming step! send w requests
    for (int i = 0; i < w; i++)
    {
        int sz = request_buffer->pop(buf, 1024);
        if (*(MESSAGE_TYPE *)buf == QUIT_MSG)
        {
            quit_recv = true;
            break;
        }
        wchan[i]->cwrite(buf, sz);

        // state is recorded here
        state[i] = vector<char>(buf, buf + sz);
        num_sent++;
        int rfd = wchan[i]->getrfd();
        fcntl(rfd, F_SETFL, O_NONBLOCK);
        first.events = EPOLLIN | EPOLLET;
        first.data.fd = rfd;
        index_fd[rfd] = i;
        if (epoll_ctl(epoll_file, EPOLL_CTL_ADD, rfd, &first) == -1)
        {
            EXITONERROR("epoll_ctl: listen_sock");
        }
    }

    // starting here, received and sent should not have anything in them.
    while (true)
    {
        if (quit_recv && num_recv == num_sent)
        {
            break;
        }
        // continuously polling
        int nfds = epoll_wait(epoll_file, events, w, -1);
        if (nfds == -1)
        {
            EXITONERROR("epoll_wait");
        }
        for (int i = 0; i < nfds; i++)
        {
            int rfd = events[i].data.fd;
            int index = index_fd[rfd];
            int resp_size = wchan[index]->cread(recvbuf, mb);
            num_recv++;
            // process the buf
            vector<char> req = state[index];
            char *request = req.data();
            // processing resp
            MESSAGE_TYPE *m = (MESSAGE_TYPE *)request;
            if (*m == DATA_MSG)
            {
                hc->update(((datamsg *)request)->person, *(double *)recvbuf);
            }
            else if (*m == FILE_MSG)
            {
                filemsg *f = (filemsg *)m;
                string filename = (char *)(f + 1);
                string recvfname = "recv/" + filename;
                FILE *fp = fopen(recvfname.c_str(), "r+");
                fseek(fp, f->offset, SEEK_SET);
                fwrite(recvbuf, 1, f->length, fp);
                fclose(fp);
            }
            // cycle through the chan
            if (!quit_recv)
            {
                int req_size = request_buffer->pop(buf, sizeof(buf));
                if (*(MESSAGE_TYPE *)buf == QUIT_MSG)
                {
                    quit_recv = true;
                }
                else
                {
                    // state is updated
                    wchan[index]->cwrite(buf, req_size);
                    state[index] = vector<char>(buf, buf + req_size);
                    num_sent++;
                }
            }
        }
    }
}

int main(int argc, char *argv[])
{
    int n = 15;
    int p = 10;
    int w = 10;
    int b = 100;
    int m = MAX_MESSAGE;
    srand(time_t(NULL));
    string fname = "";
    bool p_req = false;
    bool f_req = false;
    string printing = "";
    int opt = -1;
    while ((opt = getopt(argc, argv, "w:p:f:m:n:b:")) != -1)
    {
        switch (opt)
        {
        case 'm':
            m = atoi(optarg);
            printing = optarg;
            break;
        case 'n':
            n = atoi(optarg);
            break;
        case 'p':
            p = atoi(optarg);
            p_req = true;
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 'w':
            w = atoi(optarg);
            break;
        case 'f':
            fname = optarg;
            f_req = true;
            break;
        }
    }
    if(printing == "")
    {
        printing = "256";
    }
    int pid = fork();
    if (pid == 0)
    {
        execl("server", "server", "-m", (char*)printing.c_str(), (char*)NULL);
    }

    FIFORequestChannel *chan = new FIFORequestChannel("control", FIFORequestChannel::CLIENT_SIDE);
    BoundedBuffer request_buffer(b);
    HistogramCollection hc;

    //Histogram stuff....

    for (int i = 0; i < p; i++)
    {
        Histogram *h = new Histogram(10, -2.0, 2.0);
        hc.add(h);
    }

    struct timeval start, end;
    gettimeofday(&start, 0);

    FIFORequestChannel *wchan[w];

    // threads starting....

    if(p_req)
    {
        for(int i = 0; i < w; i++)
        {
            wchan[i] = create_new_channel(chan);
        }

        thread patient[p];
        for(int i = 0; i < p; i++)
        {
            patient[i] = thread(patient_thread_function, n, i+1, &request_buffer);
        }

        thread evp(event_polls, n, p, w, m, (FIFORequestChannel**)wchan, &request_buffer, &hc);

        for(int i = 0; i < p; i++)
        {
            patient[i].join();
        }

        cout << "Patient threads have completed." << endl;

        MESSAGE_TYPE q = QUIT_MSG;
        request_buffer.push((char*)&q, sizeof(q));

        evp.join();
        cout << "Worker threads have completed." << endl;
    }

    if(f_req)
    {
        for(int i = 0; i < w; i++)
        {
            wchan[i] = create_new_channel(chan);
        }

        thread file_thread(file_thread_function, fname, &request_buffer, chan, m);
        thread evp(event_polls, n, p, w, m, (FIFORequestChannel**)wchan, &request_buffer, &hc);

        file_thread.join();
        cout << "File threads have completed." << endl;

        MESSAGE_TYPE q = QUIT_MSG;
        request_buffer.push((char*)&q, sizeof(q));

        evp.join();
        cout << "Worker threads have completed." << endl;
    }
    gettimeofday(&end, 0);
    hc.print();
    int secs = (end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec) / (int)1e6;
    int usecs = (int)(end.tv_sec * 1e6 + end.tv_usec - start.tv_sec * 1e6 - start.tv_usec) % ((int)1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;
    MESSAGE_TYPE q = QUIT_MSG;
    for(int i = 0; i < w; i++)
    {
        wchan[i]->cwrite((char*)&q, sizeof(MESSAGE_TYPE));
        delete wchan[i];
    }
    cout << "ALl worker channls have been deleted." << endl;
    chan->cwrite((char *)&q, sizeof(MESSAGE_TYPE));
    cout << "All Done!!!" << endl;
    delete chan;
    wait(0);
}
