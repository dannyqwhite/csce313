#ifndef BoundedBuffer_h
#define BoundedBuffer_h

#include <stdio.h>
#include <queue>
#include <string>
#include <thread>
#include <mutex>
#include <assert.h>
#include <vector>
#include <condition_variable>

using namespace std;

class BoundedBuffer
{
private:
	int cap;
	queue<vector<char>> q;
	mutex m;
	condition_variable data_available;
	condition_variable slot_available;


public:
	BoundedBuffer(int _cap){
		cap = _cap;
	}
	~BoundedBuffer(){

	}

	void push(char* data, int len){

		vector<char> d (data, data + len);
		unique_lock<mutex> l (m);
		slot_available.wait (l, [this]{return q.size() < cap ;});
		q.push(d);
		l.unlock();
		data_available.notify_one();
		
	}

	int pop(char* buf, int bufcap){

		unique_lock<mutex> l (m);
		data_available.wait (l, [this]{return q.size() > 0;});
		vector<char> d = q.front();
		q.pop();
		l.unlock();
		assert(d.size() <= bufcap);
		memcpy(buf, d.data(), d.size());
		slot_available.notify_one ();
		return d.size();
	}
};

#endif
