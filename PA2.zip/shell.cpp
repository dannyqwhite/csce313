#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sstream>
#include <iterator>
#include <vector>
#include <string>
#include <chrono>

using namespace std;
string trims(const string &str)
{
    if(str.length() == 0){
        return str;
    }

    size_t start =  str.find_first_not_of(" \t\n");
    size_t end = str.find_last_not_of(" \t\n");

    return str.substr(start, end - start + 1);
}
char** vec_to_char(vector<string> &vec)
{
    char** c = new char*[vec.size()+1];
    for(int i = 0; i < vec.size(); ++i)
    {
        const char* cpy = vec[i].c_str();
        c[i] = new char[strlen(cpy)];
        strcpy(c[i], cpy);
    }
    c[vec.size()] = NULL;
    return c;
}
vector<string> split(string str)
{
    vector<string> vec;
    istringstream ss(str);
    while(ss)
    {
        string opt;
        ss >> opt;
        if(opt != "")
            vec.push_back(opt);
    }
    return vec;
}
vector<string> split(string str, string del)
{
    vector<string> vec;
    size_t pos;
    while ((pos = str.find(del)) != string::npos)
    {
        string str1 = str.substr(0, pos);
        vec.push_back(trims(str1));
        str.erase(0, pos + del.length());
    }
    vec.push_back(trims(str));
    return vec;
}

int main()
{
    vector<string> hist;
    char* user_name = new char[30];
    getlogin_r(user_name, 30);

    while(true)
    {
        time_t t = chrono::system_clock::to_time_t(chrono::system_clock::now());
        auto time = localtime(&t);
        cout << time->tm_hour << ":" << time->tm_min << "_"
             << time->tm_mon << "/" << time->tm_mday << "_";
        cout << "user[" << user_name << "]" << "$";
        string line_in;
        getline(cin, line_in);
        if(line_in == string("exit"))
        {
            cout << "Shell exited." << endl;
            break;
        }
        hist.push_back(line_in);
        vector<string> pipez = split(line_in, "|");
        int std = dup(0);
        for(int i = 0; i < pipez.size(); ++i)
        {
            int fd[2];
            pipe(fd);
            line_in = pipez[i];
            bool bg = false;
            line_in = trims(line_in);
            if(line_in[line_in.size()-1] == '&')
            {
                bg = true;
                line_in = line_in.substr(0,line_in.size()-1);
            }
            int pid = fork();
            if(pid == 0)
            {
                int position = line_in.find('>');
                if(position != -1)
                {
                    string cmd = trims(line_in.substr(0,position));
                    string file_n = trims(line_in.substr(position+1));
                    line_in = cmd;
                    int fd = open(file_n.c_str(), O_WRONLY|O_CREAT, S_IWUSR|S_IRUSR);
                    dup2(fd, 1);
                    close(fd);
                }
                position = line_in.find('<');
                if(position != -1) {
                    string cmd = trims(line_in.substr(0,position));
                    string file_n = trims(line_in.substr(position+1));
                    line_in = cmd;
                    int fd = open(file_n.c_str(), O_RDONLY, S_IWUSR|S_IRUSR);
                    dup2(fd, 0);
                    close(fd);
                }
                if(i < pipez.size()-1)
                {
                    dup2(fd[1], 1);
                }
                vector<string> options = split(line_in);
                char** argument = vec_to_char(options);
                execvp(argument[0], argument);
            }
            else{
                if(!bg)
                {
                    waitpid(pid, 0, 0);
                }
                dup2(fd[0], 0);
                close(fd[1]);
            }
        }
        dup2(std,0);
    }
}




